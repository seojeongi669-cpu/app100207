import streamlit as st
import requests, json, base64, uuid, hmac
from datetime import datetime, date, timedelta
from zoneinfo import ZoneInfo

st.set_page_config(page_title="우리 가족 약통", page_icon="💙", layout="centered")
st.markdown("""<style>
#MainMenu,footer{visibility:hidden} .block-container{max-width:650px;padding-top:2rem;padding-bottom:3rem}
.stApp{background:#f5f8fc} h1{font-size:1.8rem!important} h2{font-size:1.25rem!important}
.stButton>button,.stFormSubmitButton>button{min-height:48px;border-radius:14px;font-weight:700}
div[data-testid="stVerticalBlockBorderWrapper"]{background:white;border-radius:20px}
div[data-testid="stMetric"]{background:#e8efff;padding:16px;border-radius:18px}
input{font-size:16px!important} button{touch-action:manipulation}
</style>""",unsafe_allow_html=True)
TZ=ZoneInfo('Asia/Seoul')
def now(): return datetime.now(TZ)
def today(): return now().date()
def config(k, default=''):
    try: return st.secrets.get(k,default)
    except Exception: return default

PASSWORD=str(config('FAMILY_PASSWORD'))
if not PASSWORD:
    st.title('💙 우리 가족 약통')
    st.error('설정에서 가족 비밀번호와 GitHub 저장소를 연결해 주세요.')
    st.stop()
if not st.session_state.get('authenticated'):
    st.title('💙 우리 가족 약통')
    with st.form('login'):
        pw=st.text_input('가족 비밀번호',type='password')
        enter=st.form_submit_button('들어가기',use_container_width=True,type='primary')
    if enter:
        if hmac.compare_digest(pw,PASSWORD):
            st.session_state.authenticated=True; st.rerun()
        else: st.error('비밀번호를 확인해 주세요.')
    st.stop()
TOKEN=config('GITHUB_TOKEN'); REPO=config('GITHUB_REPO'); BRANCH=config('GITHUB_BRANCH','main')
PATH=config('GITHUB_DATA_PATH','family-data.json')
if not TOKEN or not REPO:
    st.error('GitHub 연결 설정을 확인해 주세요.'); st.stop()
URL=f'https://api.github.com/repos/{REPO}/contents/{PATH}'
HEAD={'Authorization':f'Bearer {TOKEN}','Accept':'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28'}
def empty(): return {'members':[],'meds':[],'logs':[]}
def load():
    r=requests.get(URL,headers=HEAD,params={'ref':BRANCH},timeout=20)
    if r.status_code==404:
        # Verify repository/branch first: missing permission is also reported as 404.
        check=requests.get(f'https://api.github.com/repos/{REPO}/branches/{BRANCH}',headers=HEAD,timeout=20)
        check.raise_for_status()
        return empty(),None
    r.raise_for_status(); obj=r.json()
    data=json.loads(base64.b64decode(obj['content']))
    for key in ('members','meds','logs'):
        if not isinstance(data.get(key),list): raise ValueError('Invalid data')
    return data,obj['sha']
def change(fn):
    try:
        for attempt in range(4):
            data,sha=load(); fn(data)
            payload={'message':'Update family care record','branch':BRANCH,'content':base64.b64encode(json.dumps(data,ensure_ascii=False).encode()).decode()}
            if sha: payload['sha']=sha
            r=requests.put(URL,headers=HEAD,json=payload,timeout=20)
            if r.status_code in (409,422): continue
            r.raise_for_status(); st.rerun()
        st.error('다른 가족이 저장 중이에요. 다시 눌러 주세요.')
    except requests.RequestException:
        st.error('저장하지 못했어요. 연결 상태와 GitHub 설정을 확인하고 다시 눌러 주세요.')
    except (ValueError,KeyError): st.error('저장 파일 형식을 확인해 주세요.')
try: data,_=load()
except Exception:
    st.error('기록을 불러오지 못했어요. 인터넷과 GitHub 설정을 확인해 주세요.'); st.stop()

st.title('💙 우리 가족 약통')
nav=st.segmented_control('메뉴',['오늘','약 관리','가족','기록'],default='오늘',label_visibility='collapsed')
nav=nav or '오늘'
members=data['members']; names={x['id']:x['name'] for x in members}
meds=data['meds']; logs=data['logs']
def label(mid): return names.get(mid,'삭제된 가족')
def save_member(name):
    name=name.strip()
    if not name: st.warning('이름을 입력해 주세요.'); return
    if any(x['name']==name for x in members): st.warning('이미 있는 이름이에요.'); return
    ident=uuid.uuid4().hex
    def fn(d):
        if not any(x['name']==name for x in d['members']): d['members'].append({'id':ident,'name':name})
    change(fn)
def add_member_form(key):
    with st.form(key,clear_on_submit=True):
        name=st.text_input('가족 이름',placeholder='엄마, 아빠, 나')
        if st.form_submit_button('가족 추가',type='primary',use_container_width=True): save_member(name)
def active(m,dt):
    return m.get('enabled',True) and m['start']<=dt.isoformat() and (not m.get('end') or dt.isoformat()<=m['end']) and dt.weekday() in m.get('days',list(range(7)))

def record(m,slot,done):
    day=today().isoformat(); mid=m['id']; actor=st.session_state.get('viewer',m['member'])
    def fn(d):
        if not any(x['id']==mid for x in d['meds']): return
        d['logs']=[x for x in d['logs'] if not (x['med']==mid and x['date']==day and x['slot']==slot)]
        if done: d['logs'].append({'id':uuid.uuid4().hex,'med':mid,'member':m['member'],'name':m['name'],'dose':m['dose'],'date':day,'slot':slot,'at':now().isoformat(),'actor':label(actor)})
    change(fn)

if not members:
    st.subheader('함께할 가족을 추가해 주세요')
    add_member_form('first')
    st.stop()

if nav=='오늘':
    selected=st.selectbox('누구의 약인가요?',list(names),format_func=label,key='viewer')
    a,b=st.columns([3,1]); a.subheader(today().strftime('%m월 %d일'))
    if b.button('새로고침',use_container_width=True): st.rerun()
    scheduled=sorted([(m,t) for m in meds if m['member']==selected and active(m,today()) for t in m['times']],key=lambda x:x[1])
    donekeys={(x['med'],x['slot']) for x in logs if x['date']==today().isoformat()}
    done=sum((m['id'],t) in donekeys for m,t in scheduled)
    st.progress(done/len(scheduled) if scheduled else 0,text=f'오늘 복약 {done} / {len(scheduled)}')
    if not scheduled: st.info('오늘 먹을 약이 없어요.')
    for m,t in scheduled:
        taken=(m['id'],t) in donekeys
        with st.container(border=True):
            c1,c2=st.columns([3,1.2])
            c1.subheader(('✅ ' if taken else '💊 ')+m['name'])
            c1.write(f"{t} · {m['dose']}")
            if m.get('note'): c1.caption(m['note'])
            if c2.button('취소' if taken else '먹었어요',key=f"take_{m['id']}_{t}",type='secondary' if taken else 'primary',use_container_width=True): record(m,t,not taken)
    if scheduled and done==len(scheduled): st.success('오늘 약을 모두 챙겼어요 💙')

elif nav=='약 관리':
    with st.expander('＋ 약 추가',expanded=not meds):
        with st.form('add_med',clear_on_submit=True):
            who=st.selectbox('먹는 가족',list(names),format_func=label)
            name=st.text_input('약 이름')
            dose=st.text_input('한 번 먹는 양',placeholder='예: 1정')
            times=st.text_input('먹는 시간',value='09:00',placeholder='09:00, 13:00, 19:00')
            days=st.multiselect('요일',['월','화','수','목','금','토','일'],default=['월','화','수','목','금','토','일'])
            start=st.date_input('시작일',today())
            limited=st.checkbox('종료일 있음')
            end=st.date_input('종료일',today()+timedelta(days=7))
            note=st.text_input('메모',placeholder='예: 식후')
            submit=st.form_submit_button('등록',type='primary',use_container_width=True)
        if submit:
            try:
                ts=sorted(set(datetime.strptime(x.strip(),'%H:%M').strftime('%H:%M') for x in times.split(',')))
                if not name.strip() or not dose.strip() or not days or (limited and end<start): raise ValueError()
                item={'id':uuid.uuid4().hex,'member':who,'name':name.strip(),'dose':dose.strip(),'times':ts,'days':[['월','화','수','목','금','토','일'].index(x) for x in days],'start':start.isoformat(),'end':end.isoformat() if limited else '', 'note':note.strip(),'enabled':True}
                change(lambda d:d['meds'].append(item))
            except ValueError: st.warning('이름·용량·요일·날짜와 시간을 확인해 주세요. 시간은 09:00처럼 적어 주세요.')
    target=st.selectbox('가족', ['all']+list(names),format_func=lambda x:'전체' if x=='all' else label(x))
    for m in meds:
        if target!='all' and m['member']!=target: continue
        with st.container(border=True):
            st.subheader(m['name'])
            st.write(f"{label(m['member'])} · {m['dose']} · {', '.join(m['times'])}")
            st.caption(' · '.join(['월','화','수','목','금','토','일'][i] for i in m['days'])+f" / {m['start']} ~ {m.get('end') or '계속'}")
            if m.get('note'): st.write(m['note'])
            mid=m['id']; enabled=m.get('enabled',True)
            if st.button('복약 잠시 중지' if enabled else '복약 다시 시작',key='toggle'+mid):
                def toggle(d,mid=mid,enabled=enabled):
                    for x in d['meds']:
                        if x['id']==mid:x['enabled']=not enabled
                change(toggle)
            with st.expander('삭제'):
                st.caption('이전에 먹은 기록은 남아요.')
                if st.button('이 약 삭제',key='delete'+mid):
                    change(lambda d,mid=mid:d.update(meds=[x for x in d['meds'] if x['id']!=mid]))

elif nav=='가족':
    for member in members:
        with st.container(border=True): st.subheader('👤 '+member['name'])
    add_member_form('member')
    if st.button('로그아웃',use_container_width=True):
        st.session_state.clear(); st.rerun()

elif nav=='기록':
    target=st.selectbox('가족',['all']+list(names),format_func=lambda x:'전체' if x=='all' else label(x))
    day=st.date_input('날짜',today())
    rows=sorted([x for x in logs if x['date']==day.isoformat() and (target=='all' or x['member']==target)],key=lambda x:x['at'],reverse=True)
    st.caption(f'먹은 기록 {len(rows)}건')
    if not rows: st.info('먹은 기록이 없어요.')
    for x in rows:
        with st.container(border=True):
            st.subheader('✅ '+x['name'])
            st.write(f"{label(x['member'])} · {x['dose']} · 예정 {x['slot']}")
            st.caption('기록 '+datetime.fromisoformat(x['at']).strftime('%H:%M'))
    export=json.dumps(data,ensure_ascii=False,indent=2)
    st.download_button('전체 기록 백업',export,'family-backup.json','application/json',use_container_width=True)
